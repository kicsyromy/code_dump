
#include <math.h>
#include <stdio.h>



void main(void)
{

long x,y,z;

// add the longs and see what assembly language is generated

z = x+y;

} // end main

